import os
import pandas as pd

cif_folder_path = r'cif_files'

cif_files = os.listdir(cif_folder_path)

cif_filenames = [f for f in cif_files if f.endswith('.cif')]

cif_ids = [os.path.splitext(f)[0] for f in cif_filenames]

df = pd.DataFrame(cif_ids)

output_csv_path = r'cif_files\id_prop.csv'
df.to_csv(output_csv_path, index=False,header=False)

print(f'Saved as {output_csv_path}')
